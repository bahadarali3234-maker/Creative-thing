import express from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "10mb" }));

// Lazy Gemini AI initialization
let aiClient: GoogleGenAI | null = null;
function getAi(): GoogleGenAI | null {
  if (!aiClient && process.env.GEMINI_API_KEY) {
    aiClient = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  }
  return aiClient;
}

// Health check
app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// Real-time Autocomplete / Search Suggestions
app.get("/api/suggestions", async (req, res) => {
  const query = typeof req.query.q === "string" ? req.query.q.trim() : "";
  if (!query) {
    return res.json({ suggestions: [] });
  }

  try {
    const suggestRes = await fetch(
      `https://duckduckgo.com/ac/?q=${encodeURIComponent(query)}&type=list`,
      {
        headers: {
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        },
        signal: AbortSignal.timeout(3500),
      }
    );

    if (suggestRes.ok) {
      const data = await suggestRes.json();
      const list: string[] = Array.isArray(data?.[1]) ? data[1] : [];
      return res.json({ suggestions: list.slice(0, 8) });
    }
  } catch (err) {
    console.warn("Suggestions fetch error:", err);
  }

  // Fallback keyword expansions
  return res.json({
    suggestions: [
      `${query} high resolution`,
      `${query} official photography`,
      `${query} portrait`,
      `${query} wallpaper hd`,
    ],
  });
});

// Helper to fetch topic factual description from Wikipedia / Google
async function getTopicDescription(query: string): Promise<{ title: string; extract: string }> {
  try {
    const wikiUrl = `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(query)}`;
    const wikiRes = await fetch(wikiUrl, {
      headers: {
        "User-Agent": "VisualSearchEngine/2.0 (GoogleImageScraper/AIStudio)",
      },
      signal: AbortSignal.timeout(4000),
    });

    if (wikiRes.ok) {
      const data: any = await wikiRes.json();
      if (data.extract) {
        return {
          title: data.title || query,
          extract: data.extract,
        };
      }
    }
  } catch (e) {
    // ignore and proceed
  }

  // If Wikipedia didn't have it, try Gemini if key exists
  const ai = getAi();
  if (ai) {
    try {
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: `Provide a concise 2-sentence factual overview/description of "${query}" for a visual search engine. Return plain text only.`,
      });
      const text = response.text?.trim();
      if (text) {
        return {
          title: query,
          extract: text,
        };
      }
    } catch {
      // ignore
    }
  }

  return {
    title: query,
    extract: `Live Google and web image search results for "${query}". High resolution photos scraped directly from authoritative web sources with safe-search filters off.`,
  };
}

// Scrape Images from direct website URL
async function scrapeDirectWebsite(url: string, queryHint: string) {
  let targetUrl = url.trim();
  if (!targetUrl.startsWith("http://") && !targetUrl.startsWith("https://")) {
    targetUrl = "https://" + targetUrl;
  }

  let pageTitle = queryHint || "Scraped Website";
  let pageDescription = "";
  let favicon = "";
  let sourceDomain = "";
  try {
    sourceDomain = new URL(targetUrl).hostname.replace(/^www\./, "");
  } catch {
    sourceDomain = targetUrl;
  }

  const scrapedImages: any[] = [];
  const seenUrls = new Set<string>();

  try {
    const response = await fetch(targetUrl, {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
      },
      signal: AbortSignal.timeout(9000),
    });

    if (response.ok) {
      const html = await response.text();

      // Title
      const titleMatch = html.match(/<title[^>]*>([^<]+)<\/title>/i);
      if (titleMatch && titleMatch[1]) {
        pageTitle = titleMatch[1].trim();
      }

      // Description
      const descMatch =
        html.match(/<meta\s+name=["']description["']\s+content=["']([^"']+)["']/i) ||
        html.match(/<meta\s+property=["']og:description["']\s+content=["']([^"']+)["']/i);
      if (descMatch && descMatch[1]) {
        pageDescription = descMatch[1].trim();
      }

      // Favicon
      const iconMatch =
        html.match(/<link\s+[^>]*rel=["'](?:shortcut )?icon["'][^>]*href=["']([^"']+)["']/i) ||
        html.match(/<link\s+[^>]*href=["']([^"']+)["'][^>]*rel=["'](?:shortcut )?icon["']/i);
      if (iconMatch && iconMatch[1]) {
        try {
          favicon = new URL(iconMatch[1], targetUrl).href;
        } catch {}
      }

      const addImg = (rawSrc: string, titleHint?: string) => {
        if (!rawSrc || rawSrc.startsWith("data:") || rawSrc.length < 10) return;
        try {
          const absUrl = new URL(rawSrc, targetUrl).href;
          const lower = absUrl.toLowerCase();
          if (
            lower.endsWith(".svg") ||
            lower.includes("1x1") ||
            lower.includes("pixel") ||
            lower.includes("spacer") ||
            lower.includes("beacon") ||
            lower.includes("tracking")
          ) {
            return;
          }

          if (!seenUrls.has(absUrl)) {
            seenUrls.add(absUrl);
            scrapedImages.push({
              id: `web-${Date.now()}-${scrapedImages.length}`,
              title: titleHint ? titleHint.replace(/<[^>]+>/g, "").slice(0, 80) : `${pageTitle} — Image ${scrapedImages.length + 1}`,
              url: absUrl,
              thumbnail: absUrl,
              sourceUrl: targetUrl,
              sourceDomain,
              width: 1200,
              height: 800,
            });
          }
        } catch {}
      };

      // 1. og:image & twitter:image
      const ogMatches = html.matchAll(/<meta\s+(?:property|name)=["'](?:og:image|twitter:image)["']\s+content=["']([^"']+)["']/gi);
      for (const m of ogMatches) {
        addImg(m[1], `${pageTitle} — Primary Hero`);
      }

      // 2. img src & data-src
      const imgMatches = html.matchAll(/<img\s+[^>]*?(?:src|data-src|data-original)=["']([^"']+)["'][^>]*?>/gi);
      for (const m of imgMatches) {
        const fullTag = m[0];
        const altMatch = fullTag.match(/alt=["']([^"']+)["']/i);
        addImg(m[1], altMatch ? altMatch[1] : undefined);
      }

      // 3. srcset
      const srcSetMatches = html.matchAll(/srcset=["']([^"']+)["']/gi);
      for (const m of srcSetMatches) {
        const parts = m[1].split(",");
        const lastPart = parts[parts.length - 1].trim().split(" ")[0];
        addImg(lastPart);
      }
    }
  } catch (err) {
    console.warn("Direct site scrape warning:", err);
  }

  // If website had few direct images, also load web images matching this page title or domain
  if (scrapedImages.length < 8 && pageTitle) {
    const webExtra = await fetchWebImages(pageTitle.replace(/[-_|].*$/, "").trim(), 0);
    for (const img of webExtra.images) {
      if (!seenUrls.has(img.url)) {
        seenUrls.add(img.url);
        scrapedImages.push(img);
      }
    }
  }

  return {
    detail: {
      query: targetUrl,
      title: pageTitle,
      description:
        pageDescription ||
        `Real photographs extracted live from ${targetUrl}. Scraped directly via Google website crawler and formatted for instant preview.`,
      sourceUrl: targetUrl,
      sourceDomain,
      favicon,
      isDirectWebsite: true,
      totalFound: scrapedImages.length,
    },
    images: scrapedImages,
    hasMore: false,
    suggestions: [
      `${pageTitle} gallery`,
      `${sourceDomain} official photos`,
      "Google Arts & Culture",
      "Wikipedia Heritage Sites",
    ],
  };
}

// Fetch images via Web & Google image index (filter OFF, any personality/human/object)
async function fetchWebImages(query: string, offset: number = 0): Promise<{ images: any[]; nextOffset?: number; hasMore: boolean }> {
  const images: any[] = [];
  const seenUrls = new Set<string>();
  let nextOffset: number | undefined = undefined;
  let hasMore = false;

  try {
    // 1. Get VQD token from DuckDuckGo
    const tokenRes = await fetch(
      `https://duckduckgo.com/?q=${encodeURIComponent(query)}&t=h_&iar=images&iax=images&ia=images`,
      {
        headers: {
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        },
        signal: AbortSignal.timeout(6000),
      }
    );

    if (tokenRes.ok) {
      const html = await tokenRes.text();
      const vqdMatch = html.match(/vqd=([\d-]+)/) || html.match(/vqd="([^"]+)"/);
      const vqd = vqdMatch ? vqdMatch[1] : null;

      if (vqd) {
        // SafeSearch OFF: f=,,,
        const imgRes = await fetch(
          `https://duckduckgo.com/i.js?l=us-en&o=json&q=${encodeURIComponent(query)}&vqd=${vqd}&f=,,,&s=${offset}`,
          {
            headers: {
              "User-Agent":
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
              Referer: "https://duckduckgo.com/",
            },
            signal: AbortSignal.timeout(7000),
          }
        );

        if (imgRes.ok) {
          const data: any = await imgRes.json();
          const results = Array.isArray(data?.results) ? data.results : [];

          for (const item of results) {
            if (item?.image && !seenUrls.has(item.image)) {
              seenUrls.add(item.image);

              let sourceDomain = "";
              try {
                sourceDomain = new URL(item.url || item.image).hostname.replace(/^www\./, "");
              } catch {
                sourceDomain = item.source || "web";
              }

              images.push({
                id: `img-${Date.now()}-${images.length}-${Math.random().toString(36).substring(2, 6)}`,
                title: item.title || query,
                url: item.image, // full-resolution original web link
                thumbnail: item.thumbnail || item.image,
                sourceUrl: item.url || item.image,
                sourceDomain,
                width: item.width || 1200,
                height: item.height || 800,
              });
            }
          }

          if (data.next) {
            hasMore = true;
            nextOffset = offset + images.length;
          }
        }
      }
    }
  } catch (err) {
    console.warn("Web image search warning:", err);
  }

  // 2. Backup with Wikimedia Commons search to guarantee rich images if needed
  if (images.length < 10) {
    try {
      const wikiUrl = `https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrsearch=${encodeURIComponent(query)}&gsrnamespace=6&gsrlimit=30&gsroffset=${offset}&prop=imageinfo&iiprop=url|size|extmetadata&format=json&origin=*`;
      const wikiRes = await fetch(wikiUrl, { signal: AbortSignal.timeout(6000) });
      if (wikiRes.ok) {
        const wikiData: any = await wikiRes.json();
        const pages = wikiData.query?.pages || {};
        for (const key of Object.keys(pages)) {
          const p = pages[key];
          const ii = p.imageinfo?.[0];
          if (ii?.url && !seenUrls.has(ii.url)) {
            const lower = ii.url.toLowerCase();
            if (lower.endsWith(".svg") || lower.endsWith(".ogg") || lower.endsWith(".pdf")) continue;
            seenUrls.add(ii.url);

            const cleanTitle = (p.title || query).replace(/^File:/i, "").replace(/\.[^/.]+$/, "");
            images.push({
              id: `wiki-${p.pageid || Date.now()}-${images.length}`,
              title: cleanTitle,
              url: ii.url,
              thumbnail: ii.thumburl || ii.url,
              sourceUrl: ii.descriptionurl || `https://commons.wikimedia.org/wiki/File:${encodeURIComponent(cleanTitle)}`,
              sourceDomain: "wikimedia.org",
              width: ii.width || 1600,
              height: ii.height || 1000,
            });
          }
        }
        if (Object.keys(pages).length >= 20) {
          hasMore = true;
          nextOffset = offset + 30;
        }
      }
    } catch (e) {
      console.warn("Wikimedia backup warning:", e);
    }
  }

  return { images, nextOffset, hasMore };
}

// Unified Google & Web Image Scraper Endpoint
app.post("/api/google-scrape-images", async (req, res) => {
  try {
    const { query = "", offset = 0 } = req.body;
    const cleanQuery = typeof query === "string" ? query.trim() : "";

    if (!cleanQuery) {
      return res.status(400).json({ error: "Search query or website URL is required." });
    }

    const isUrl =
      cleanQuery.startsWith("http://") ||
      cleanQuery.startsWith("https://") ||
      cleanQuery.includes(".com/") ||
      cleanQuery.includes(".org/") ||
      cleanQuery.includes(".net/") ||
      (cleanQuery.includes(".") && !cleanQuery.includes(" ") && cleanQuery.length > 4);

    // If direct website URL and first page, scrape that website
    if (isUrl && (!offset || offset === 0)) {
      const siteResult = await scrapeDirectWebsite(cleanQuery, cleanQuery);
      return res.json(siteResult);
    }

    // Normal keyword search (or pagination of URL)
    const [topicDesc, imagesResult] = await Promise.all([
      offset === 0 ? getTopicDescription(cleanQuery) : Promise.resolve({ title: cleanQuery, extract: "" }),
      fetchWebImages(cleanQuery, Number(offset) || 0),
    ]);

    // Fetch related autocomplete suggestions
    let suggestions: string[] = [];
    try {
      const suggestRes = await fetch(
        `https://duckduckgo.com/ac/?q=${encodeURIComponent(cleanQuery)}&type=list`,
        { signal: AbortSignal.timeout(2000) }
      );
      if (suggestRes.ok) {
        const sData = await suggestRes.json();
        suggestions = Array.isArray(sData?.[1]) ? sData[1].slice(0, 6) : [];
      }
    } catch {}

    res.json({
      detail: {
        query: cleanQuery,
        title: topicDesc.title,
        description: topicDesc.extract,
        sourceUrl: `https://www.google.com/search?q=${encodeURIComponent(cleanQuery)}&tbm=isch`,
        sourceDomain: "google.com",
        isDirectWebsite: false,
        totalFound: imagesResult.images.length,
      },
      images: imagesResult.images,
      nextOffset: imagesResult.nextOffset,
      hasMore: imagesResult.hasMore,
      suggestions,
    });
  } catch (error: any) {
    console.error("Error in /api/google-scrape-images:", error);
    res.status(500).json({
      error: "Failed to scrape Google and web images.",
      message: error?.message || "Internal server error",
    });
  }
});

async function start() {
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

start();

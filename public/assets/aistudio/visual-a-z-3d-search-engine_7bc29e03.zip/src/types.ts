export interface ScrapedImage {
  id: string;
  title: string;
  url: string;
  thumbnail: string;
  sourceUrl: string;
  sourceDomain: string;
  width?: number;
  height?: number;
  aspectRatio?: "landscape" | "portrait" | "square";
}

export type ViewMode = "bento" | "grid";

export interface GoogleSearchDetail {
  query: string;
  title: string;
  description: string;
  sourceUrl?: string;
  sourceDomain?: string;
  favicon?: string;
  isDirectWebsite: boolean;
  totalFound: number;
}

export interface GoogleImagesApiResponse {
  detail: GoogleSearchDetail;
  images: ScrapedImage[];
  nextOffset?: number;
  hasMore: boolean;
  suggestions: string[];
}

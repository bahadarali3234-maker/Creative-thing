import React, { useState } from "react";
import { GoogleSearchDetail } from "../types";
import { Globe, ExternalLink, Copy, Check, Info, Sparkles } from "lucide-react";

interface GoogleDetailCardProps {
  detail: GoogleSearchDetail;
}

export const GoogleDetailCard: React.FC<GoogleDetailCardProps> = ({ detail }) => {
  const [copied, setCopied] = useState(false);

  const handleCopySummary = () => {
    const textToCopy = `${detail.title}\n\n${detail.description}\n\nSource: ${detail.sourceUrl || "Google Web"}`;
    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-8">
      <div className="rounded-3xl bg-white/95 border border-stone-200/90 p-6 sm:p-7 shadow-3d-light relative overflow-hidden transition-all">
        {/* Accent Top Gradient Line */}
        <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-emerald-500 via-teal-500 to-amber-500" />

        <div className="flex flex-col md:flex-row md:items-start justify-between gap-5">
          <div className="flex items-start gap-4">
            {detail.favicon ? (
              <img
                src={detail.favicon}
                alt="Site Icon"
                referrerPolicy="no-referrer"
                className="w-12 h-12 rounded-2xl object-cover border border-stone-200 shadow-sm bg-white p-1 flex-shrink-0"
              />
            ) : (
              <div className="w-12 h-12 rounded-2xl bg-emerald-100 border border-emerald-200 text-emerald-800 flex items-center justify-center font-bold text-lg flex-shrink-0 shadow-3d-inset">
                <Globe className="w-6 h-6" />
              </div>
            )}

            <div>
              <div className="flex items-center gap-2 flex-wrap mb-1.5">
                <h2 className="font-display font-extrabold text-xl sm:text-2xl text-stone-900 leading-tight">
                  {detail.title}
                </h2>
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                  {detail.isDirectWebsite ? "Direct Scraped Website" : "Google Knowledge & Web Results"}
                </span>
              </div>

              {/* Factual Google/Wikipedia Description */}
              <p className="text-xs sm:text-sm text-stone-700 leading-relaxed max-w-3xl mb-3 font-normal">
                {detail.description}
              </p>

              {/* Meta information: Source domain and count */}
              <div className="flex items-center gap-3 text-xs text-stone-400 flex-wrap">
                <span className="font-mono text-[11px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                  {detail.sourceDomain || "google.com"}
                </span>
                <span>•</span>
                <span className="text-stone-600 font-medium">
                  {detail.totalFound} {detail.totalFound === 1 ? "Image loaded" : "Images loaded from top links"}
                </span>
                <span>•</span>
                <span className="text-amber-700 font-medium flex items-center gap-1">
                  <Sparkles className="w-3 h-3" />
                  Scroll down for auto-loading
                </span>
              </div>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="flex items-center gap-2 flex-shrink-0 self-start">
            <button
              onClick={handleCopySummary}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold shadow-xs active:translate-y-0.5 transition-all cursor-pointer"
              title="Copy description and sources"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? "Copied!" : "Copy Info"}</span>
            </button>

            {detail.sourceUrl && (
              <a
                href={detail.sourceUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-stone-900 hover:bg-black text-white text-xs font-bold shadow-3d-button active:translate-y-0.5 transition-all"
              >
                <span>Visit Source</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

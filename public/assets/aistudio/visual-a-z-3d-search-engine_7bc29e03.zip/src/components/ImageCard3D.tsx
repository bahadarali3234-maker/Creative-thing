import React, { useState } from "react";
import { ScrapedImage } from "../types";
import { Copy, Check, ExternalLink, Maximize2, Globe, Image as ImageIcon } from "lucide-react";

interface ImageCard3DProps {
  image: ScrapedImage;
  index: number;
  onPreview: (image: ScrapedImage) => void;
  isLarge?: boolean;
}

export const ImageCard3D: React.FC<ImageCard3DProps> = ({
  image,
  index,
  onPreview,
  isLarge = false,
}) => {
  const [copiedImage, setCopiedImage] = useState(false);
  const [copiedSource, setCopiedSource] = useState(false);
  const [hasError, setHasError] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);

  const handleCopyImageUrl = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(image.url);
    setCopiedImage(true);
    setTimeout(() => setCopiedImage(false), 2000);
  };

  const handleCopySourceUrl = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(image.sourceUrl);
    setCopiedSource(true);
    setTimeout(() => setCopiedSource(false), 2000);
  };

  return (
    <div
      onClick={() => onPreview(image)}
      className={`group relative rounded-3xl bg-white border border-stone-200/90 overflow-hidden shadow-3d-light hover:shadow-3d-hover transition-all duration-300 transform hover:-translate-y-1.5 cursor-pointer flex flex-col justify-between ${
        isLarge ? "sm:col-span-2 lg:col-span-2" : "col-span-1"
      }`}
    >
      {/* Top Media Container */}
      <div className="relative aspect-[4/3] w-full bg-stone-100 overflow-hidden">
        {/* Placeholder skeleton while loading */}
        {!isLoaded && !hasError && (
          <div className="absolute inset-0 bg-stone-200 animate-pulse flex items-center justify-center">
            <ImageIcon className="w-8 h-8 text-stone-400" />
          </div>
        )}

        {hasError ? (
          <div className="absolute inset-0 bg-stone-100 flex flex-col items-center justify-center text-stone-400 p-4 text-center">
            <ImageIcon className="w-8 h-8 mb-1" />
            <span className="text-[11px]">Protected or unavailable image</span>
          </div>
        ) : (
          <img
            src={image.thumbnail || image.url}
            alt={image.title}
            referrerPolicy="no-referrer"
            loading="lazy"
            onLoad={() => setIsLoaded(true)}
            onError={() => setHasError(true)}
            className={`w-full h-full object-cover transition-transform duration-500 group-hover:scale-105 ${
              isLoaded ? "opacity-100" : "opacity-0"
            }`}
          />
        )}

        {/* Index Badge */}
        <div className="absolute top-3 left-3 px-2 py-0.5 rounded-lg bg-black/60 backdrop-blur-md text-white text-[11px] font-mono font-bold shadow-sm">
          #{index + 1}
        </div>

        {/* Source Domain Pill */}
        <div className="absolute top-3 right-3 px-2.5 py-0.5 rounded-lg bg-white/90 backdrop-blur-md text-stone-800 text-[10px] font-bold border border-stone-200 shadow-sm flex items-center gap-1">
          <Globe className="w-3 h-3 text-stone-500" />
          <span className="truncate max-w-[120px]">{image.sourceDomain}</span>
        </div>

        {/* Hover Overlay Button to Expand */}
        <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
          <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/95 text-stone-900 text-xs font-bold shadow-lg transform translate-y-2 group-hover:translate-y-0 transition-transform">
            <Maximize2 className="w-3.5 h-3.5" />
            <span>Preview High-Res</span>
          </span>
        </div>
      </div>

      {/* Details & Actions Footer */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        {/* Title */}
        <h3 className="font-display font-bold text-sm text-stone-900 line-clamp-2 leading-snug mb-3">
          {image.title}
        </h3>

        {/* Action Link Controls */}
        <div className="space-y-2 pt-2 border-t border-stone-100">
          {/* Copy Direct Image URL Button */}
          <div className="flex items-center justify-between gap-2">
            <span className="text-[11px] text-stone-400 font-medium truncate">
              Image URL
            </span>
            <button
              onClick={handleCopyImageUrl}
              className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                copiedImage
                  ? "bg-emerald-100 text-emerald-800 border border-emerald-300"
                  : "bg-stone-100 hover:bg-stone-200 text-stone-700 hover:text-stone-950"
              }`}
              title="Copy direct high-resolution image link"
            >
              {copiedImage ? (
                <>
                  <Check className="w-3 h-3 text-emerald-600" />
                  <span>Copied Link!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3 h-3 text-stone-500" />
                  <span>Copy Image Link</span>
                </>
              )}
            </button>
          </div>

          {/* Copy Source Webpage URL & Visit Link */}
          <div className="flex items-center justify-between gap-2">
            <button
              onClick={handleCopySourceUrl}
              className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-medium transition-colors cursor-pointer ${
                copiedSource
                  ? "text-emerald-700 font-bold"
                  : "text-stone-500 hover:text-stone-800"
              }`}
              title="Copy source webpage address"
            >
              {copiedSource ? (
                <>
                  <Check className="w-3 h-3 text-emerald-600" />
                  <span>Source Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3 h-3 text-stone-400" />
                  <span>Copy Source URL</span>
                </>
              )}
            </button>

            <a
              href={image.sourceUrl}
              target="_blank"
              rel="noopener noreferrer"
              onClick={(e) => e.stopPropagation()}
              className="inline-flex items-center gap-1 text-[11px] font-semibold text-blue-600 hover:text-blue-800 hover:underline"
              title="Open source website"
            >
              <span>Visit Site</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

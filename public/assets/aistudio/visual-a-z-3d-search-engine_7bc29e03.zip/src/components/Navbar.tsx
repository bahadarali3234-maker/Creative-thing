import React from "react";
import { Globe, LayoutGrid, Columns3, ExternalLink } from "lucide-react";
import { ViewMode } from "../types";

interface NavbarProps {
  viewMode: ViewMode;
  onViewModeChange: (mode: ViewMode) => void;
  totalImages: number;
  currentQuery: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  viewMode,
  onViewModeChange,
  totalImages,
  currentQuery,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-[#faf9f6]/95 backdrop-blur-md border-b border-stone-200/80 transition-all shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Logo with 3D Relief Icon */}
        <div className="flex items-center gap-3">
          <div className="relative w-10 h-10 rounded-2xl bg-gradient-to-br from-stone-900 via-stone-800 to-amber-900 flex items-center justify-center text-white shadow-3d-button transform -rotate-1 hover:rotate-0 transition-transform cursor-pointer">
            <Globe className="w-5 h-5 text-amber-300" />
            <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500" />
            </span>
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span className="font-display font-bold text-lg tracking-tight text-stone-900">
                Google Web Image Scraper
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold tracking-wide uppercase bg-emerald-100 text-emerald-800 border border-emerald-200/70 shadow-3d-inset">
                SafeSearch Off
              </span>
            </div>
            <p className="text-xs text-stone-500 hidden sm:block">
              Scrape & Preview Live Images from Any Google Website or Search Term
            </p>
          </div>
        </div>

        {/* Right Actions: View Mode Switcher & Google Link */}
        <div className="flex items-center gap-2 sm:gap-3">
          {totalImages > 0 && (
            <span className="hidden md:inline-flex items-center px-2.5 py-1 rounded-xl text-xs font-semibold bg-stone-100 border border-stone-200 text-stone-700">
              {totalImages} {totalImages === 1 ? "Image" : "Images Loaded"}
            </span>
          )}

          {/* View Switcher */}
          <div className="bg-stone-100/90 p-1 rounded-xl border border-stone-200/80 flex items-center shadow-3d-inset">
            <button
              onClick={() => onViewModeChange("bento")}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                viewMode === "bento"
                  ? "bg-white text-stone-900 shadow-3d-light font-bold"
                  : "text-stone-500 hover:text-stone-900"
              }`}
              title="3D Dynamic Bento Layout"
            >
              <LayoutGrid className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">3D Bento</span>
            </button>
            <button
              onClick={() => onViewModeChange("grid")}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                viewMode === "grid"
                  ? "bg-white text-stone-900 shadow-3d-light font-bold"
                  : "text-stone-500 hover:text-stone-900"
              }`}
              title="Equal Grid Layout"
            >
              <Columns3 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Grid</span>
            </button>
          </div>

          {currentQuery && (
            <a
              href={`https://www.google.com/search?q=${encodeURIComponent(currentQuery)}&tbm=isch`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 px-3 py-2 rounded-xl bg-white border border-stone-200 text-stone-700 hover:text-stone-900 hover:bg-stone-50 text-xs font-semibold shadow-3d-light active:translate-y-0.5 transition-all"
              title="Open raw search directly on Google Images"
            >
              <span>Google</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          )}
        </div>
      </div>
    </header>
  );
};

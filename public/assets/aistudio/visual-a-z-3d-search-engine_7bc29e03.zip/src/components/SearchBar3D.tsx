import React, { useState, useEffect, useRef } from "react";
import { Search, X, Loader2, Globe, ArrowRight, Sparkles } from "lucide-react";

interface SearchBar3DProps {
  onSearch: (query: string) => void;
  isLoading: boolean;
  initialQuery?: string;
}

export const SearchBar3D: React.FC<SearchBar3DProps> = ({
  onSearch,
  isLoading,
  initialQuery = "",
}) => {
  const [query, setQuery] = useState(initialQuery);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [activeSuggestionIndex, setActiveSuggestionIndex] = useState(-1);
  const wrapperRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setQuery(initialQuery);
  }, [initialQuery]);

  // Fetch live autocomplete suggestions as user types
  useEffect(() => {
    const trimmed = query.trim();
    if (!trimmed || trimmed.length < 2 || trimmed.startsWith("http")) {
      setSuggestions([]);
      return;
    }

    const timer = setTimeout(async () => {
      try {
        const res = await fetch(`/api/suggestions?q=${encodeURIComponent(trimmed)}`);
        if (res.ok) {
          const data = await res.json();
          setSuggestions(data.suggestions || []);
        }
      } catch (err) {
        console.warn("Autocomplete error:", err);
      }
    }, 200);

    return () => clearTimeout(timer);
  }, [query]);

  // Click outside to close suggestions
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const clean = query.trim();
    if (clean) {
      setShowSuggestions(false);
      onSearch(clean);
    }
  };

  const handleSelectSuggestion = (suggested: string) => {
    setQuery(suggested);
    setShowSuggestions(false);
    onSearch(suggested);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (suggestions.length > 0 && showSuggestions) {
      if (e.key === "ArrowDown") {
        e.preventDefault();
        setActiveSuggestionIndex((prev) => (prev < suggestions.length - 1 ? prev + 1 : 0));
        return;
      }
      if (e.key === "ArrowUp") {
        e.preventDefault();
        setActiveSuggestionIndex((prev) => (prev > 0 ? prev - 1 : suggestions.length - 1));
        return;
      }
      if (e.key === "Enter" && activeSuggestionIndex >= 0) {
        e.preventDefault();
        handleSelectSuggestion(suggestions[activeSuggestionIndex]);
        return;
      }
    }

    if (e.key === "Enter") {
      handleSubmit();
    }
  };

  const sampleQueries = [
    { label: "Cristiano Ronaldo", q: "Cristiano Ronaldo" },
    { label: "Elon Musk", q: "Elon Musk" },
    { label: "Google Arts & Culture", q: "https://artsandculture.google.com" },
    { label: "Shah Rukh Khan", q: "Shah Rukh Khan" },
    { label: "Babar Azam", q: "Babar Azam" },
    { label: "Ferrari F40", q: "Ferrari F40" },
    { label: "Wikipedia Tiger", q: "https://en.wikipedia.org/wiki/Tiger" },
    { label: "Cyberpunk City", q: "Cyberpunk City aesthetic" },
  ];

  return (
    <div className="w-full max-w-4xl mx-auto px-4 sm:px-6 my-6">
      {/* Title & Banner */}
      <div className="text-center mb-6">
        <span className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full text-xs font-bold text-emerald-800 bg-emerald-100 border border-emerald-200/80 shadow-3d-inset mb-3">
          <Globe className="w-3.5 h-3.5 text-emerald-600" />
          <span>Open Google Website / Scrape Images</span>
        </span>

        <h1 className="font-display font-extrabold text-3xl sm:text-4xl tracking-tight text-stone-900 mb-2">
          Real-Time Google Web Image Crawler
        </h1>
        <p className="text-xs sm:text-sm text-stone-500 max-w-xl mx-auto">
          Type any personality, topic, or paste a Google website URL. Real images are scraped directly from top web links and rendered into the 3D grid with instant link copying.
        </p>
      </div>

      {/* 3D Elevated Search Form */}
      <div ref={wrapperRef} className="relative">
        <div className="rounded-3xl bg-white/95 border border-stone-200/90 p-2 sm:p-3 shadow-3d-light hover:shadow-3d-hover transition-all duration-300">
          <form onSubmit={handleSubmit} className="flex items-center gap-2">
            <div className="relative flex-1 flex items-center bg-stone-50 rounded-2xl border border-stone-200 px-4 py-3 shadow-3d-inset focus-within:ring-2 focus-within:ring-stone-800/20 focus-within:border-stone-400 transition-all">
              <Search className="w-5 h-5 text-stone-400 flex-shrink-0 mr-3" />

              <input
                type="text"
                value={query}
                onChange={(e) => {
                  setQuery(e.target.value);
                  setShowSuggestions(true);
                  setActiveSuggestionIndex(-1);
                }}
                onFocus={() => {
                  if (suggestions.length > 0) setShowSuggestions(true);
                }}
                onKeyDown={handleKeyDown}
                placeholder="Search any personality, object, or paste website URL (e.g. Cristiano Ronaldo, artsandculture.google.com)..."
                className="w-full bg-transparent text-sm sm:text-base font-medium text-stone-900 placeholder-stone-400 focus:outline-none"
              />

              {query && (
                <button
                  type="button"
                  onClick={() => {
                    setQuery("");
                    setSuggestions([]);
                  }}
                  className="p-1 rounded-full text-stone-400 hover:text-stone-700 hover:bg-stone-200/60 transition-colors mr-2"
                  title="Clear search"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Submit Action Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="flex items-center gap-2 px-5 py-3.5 rounded-2xl bg-gradient-to-r from-stone-900 via-stone-800 to-amber-950 hover:from-black hover:to-amber-900 text-white text-xs sm:text-sm font-bold shadow-3d-button active:translate-y-0.5 transition-all flex-shrink-0 disabled:opacity-60 cursor-pointer"
            >
              {isLoading ? (
                <Loader2 className="w-4 h-4 animate-spin text-amber-300" />
              ) : (
                <Globe className="w-4 h-4 text-amber-300" />
              )}
              <span>Scrape Images</span>
              <ArrowRight className="w-3.5 h-3.5 hidden sm:inline" />
            </button>
          </form>
        </div>

        {/* Live Auto-Suggestions Dropdown */}
        {showSuggestions && suggestions.length > 0 && (
          <div className="absolute left-0 right-0 top-full mt-2 z-50 rounded-2xl bg-white border border-stone-200 shadow-2xl overflow-hidden animate-fadeIn">
            <div className="px-3 py-1.5 bg-stone-50 border-b border-stone-100 flex items-center justify-between text-[11px] font-bold text-stone-400 uppercase tracking-wider">
              <span>Google & Web Search Suggestions</span>
              <span className="text-[10px] font-normal lowercase">press Enter to select</span>
            </div>
            <ul className="py-1 max-h-64 overflow-y-auto divide-y divide-stone-50">
              {suggestions.map((item, idx) => (
                <li key={idx}>
                  <button
                    type="button"
                    onClick={() => handleSelectSuggestion(item)}
                    className={`w-full text-left px-4 py-2.5 flex items-center justify-between gap-3 text-xs sm:text-sm transition-colors ${
                      idx === activeSuggestionIndex
                        ? "bg-amber-50 text-stone-900 font-bold"
                        : "text-stone-700 hover:bg-stone-50"
                    }`}
                  >
                    <div className="flex items-center gap-2.5 truncate">
                      <Search className="w-3.5 h-3.5 text-stone-400 flex-shrink-0" />
                      <span className="truncate">{item}</span>
                    </div>
                    <span className="text-[11px] text-stone-400 font-medium flex-shrink-0">
                      Google Scrape
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      {/* Quick Suggestion Chips */}
      <div className="flex flex-wrap items-center justify-center gap-2 mt-4">
        <span className="text-xs font-semibold text-stone-400 flex items-center gap-1">
          <Sparkles className="w-3 h-3 text-amber-500" />
          <span>Try:</span>
        </span>
        {sampleQueries.map((item, i) => (
          <button
            key={i}
            onClick={() => {
              setQuery(item.q);
              onSearch(item.q);
            }}
            className="px-2.5 py-1 rounded-xl bg-white hover:bg-stone-100 border border-stone-200 text-stone-700 text-xs font-medium shadow-2xs hover:shadow-xs transition-all active:scale-95 cursor-pointer"
          >
            {item.label}
          </button>
        ))}
      </div>
    </div>
  );
};

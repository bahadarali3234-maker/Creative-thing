import React, { useState, useEffect } from "react";
import { ScrapedImage } from "../types";
import { X, ChevronLeft, ChevronRight, Copy, Check, ExternalLink, Download, Globe } from "lucide-react";

interface ImageModalProps {
  image: ScrapedImage | null;
  onClose: () => void;
  onNavigate: (direction: "prev" | "next") => void;
  hasPrev: boolean;
  hasNext: boolean;
}

export const ImageModal: React.FC<ImageModalProps> = ({
  image,
  onClose,
  onNavigate,
  hasPrev,
  hasNext,
}) => {
  const [copiedImage, setCopiedImage] = useState(false);
  const [copiedSource, setCopiedSource] = useState(false);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowLeft" && hasPrev) onNavigate("prev");
      if (e.key === "ArrowRight" && hasNext) onNavigate("next");
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [onClose, onNavigate, hasPrev, hasNext]);

  if (!image) return null;

  const handleCopyImg = () => {
    navigator.clipboard.writeText(image.url);
    setCopiedImage(true);
    setTimeout(() => setCopiedImage(false), 2000);
  };

  const handleCopySrc = () => {
    navigator.clipboard.writeText(image.sourceUrl);
    setCopiedSource(true);
    setTimeout(() => setCopiedSource(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-md animate-fadeIn">
      {/* Backdrop click to dismiss */}
      <div className="absolute inset-0" onClick={onClose} />

      {/* Navigation Arrows */}
      {hasPrev && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            onNavigate("prev");
          }}
          className="absolute left-4 top-1/2 -translate-y-1/2 z-20 w-11 h-11 rounded-full bg-white/90 hover:bg-white text-stone-900 shadow-xl flex items-center justify-center transition-transform hover:scale-110 active:scale-95 cursor-pointer"
          title="Previous Image (Left Arrow)"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
      )}

      {hasNext && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            onNavigate("next");
          }}
          className="absolute right-4 top-1/2 -translate-y-1/2 z-20 w-11 h-11 rounded-full bg-white/90 hover:bg-white text-stone-900 shadow-xl flex items-center justify-center transition-transform hover:scale-110 active:scale-95 cursor-pointer"
          title="Next Image (Right Arrow)"
        >
          <ChevronRight className="w-6 h-6" />
        </button>
      )}

      {/* Main Dialog Modal */}
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative z-10 w-full max-w-4xl max-h-[90vh] bg-white rounded-3xl overflow-hidden shadow-2xl flex flex-col border border-stone-200 animate-scaleUp"
      >
        {/* Header Bar */}
        <div className="px-6 py-4 border-b border-stone-200/80 flex items-center justify-between gap-4 bg-stone-50">
          <div className="flex items-center gap-2 truncate">
            <span className="px-2.5 py-0.5 rounded-lg bg-stone-200 text-stone-800 text-xs font-bold font-mono">
              {image.sourceDomain}
            </span>
            <h3 className="font-display font-bold text-sm sm:text-base text-stone-900 truncate">
              {image.title}
            </h3>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-stone-200/70 hover:bg-stone-300 text-stone-700 flex items-center justify-center transition-colors cursor-pointer flex-shrink-0"
            title="Close (Esc)"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Image Preview Canvas */}
        <div className="relative flex-1 min-h-[300px] max-h-[60vh] bg-stone-950 flex items-center justify-center p-4 overflow-hidden">
          <img
            src={image.url}
            alt={image.title}
            referrerPolicy="no-referrer"
            className="max-w-full max-h-[56vh] object-contain rounded-xl shadow-2xl"
          />
        </div>

        {/* Footer with Direct Links & Copy Actions */}
        <div className="p-6 bg-white border-t border-stone-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1 max-w-md">
            <div className="flex items-center gap-2 text-xs text-stone-400">
              <span>Direct Link:</span>
              <span className="font-mono text-[11px] text-stone-600 truncate max-w-xs">
                {image.url}
              </span>
            </div>
            <div className="flex items-center gap-2 text-xs text-stone-400">
              <span>Source Webpage:</span>
              <span className="font-mono text-[11px] text-stone-600 truncate max-w-xs">
                {image.sourceUrl}
              </span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
            <button
              onClick={handleCopyImg}
              className={`flex-1 sm:flex-none inline-flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer ${
                copiedImage
                  ? "bg-emerald-600 text-white"
                  : "bg-stone-900 hover:bg-stone-800 text-white"
              }`}
            >
              {copiedImage ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedImage ? "Image Link Copied!" : "Copy Image Link"}</span>
            </button>

            <button
              onClick={handleCopySrc}
              className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                copiedSource
                  ? "bg-emerald-50 text-emerald-800 border-emerald-300"
                  : "bg-stone-100 hover:bg-stone-200 text-stone-700 border-stone-200"
              }`}
            >
              {copiedSource ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedSource ? "Source Copied!" : "Copy Source"}</span>
            </button>

            <a
              href={image.url}
              target="_blank"
              rel="noopener noreferrer"
              download
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 text-xs font-bold border border-amber-200 transition-colors"
            >
              <ExternalLink className="w-3.5 h-3.5 text-amber-700" />
              <span>Open Image</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

import React, { useState, useEffect, useRef, useCallback } from "react";
import { Navbar } from "./components/Navbar";
import { SearchBar3D } from "./components/SearchBar3D";
import { GoogleDetailCard } from "./components/GoogleDetailCard";
import { ImageCard3D } from "./components/ImageCard3D";
import { ImageModal } from "./components/ImageModal";
import { ScrapedImage, GoogleSearchDetail, ViewMode, GoogleImagesApiResponse } from "./types";
import { Loader2, Copy, Check, Sparkles, Image as ImageIcon, ArrowDown, ExternalLink } from "lucide-react";

export default function App() {
  const [query, setQuery] = useState("Cristiano Ronaldo");
  const [searchDetail, setSearchDetail] = useState<GoogleSearchDetail | null>(null);
  const [images, setImages] = useState<ScrapedImage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(false);
  const [nextOffset, setNextOffset] = useState<number | undefined>(undefined);
  const [viewMode, setViewMode] = useState<ViewMode>("bento");
  const [selectedImage, setSelectedImage] = useState<ScrapedImage | null>(null);
  const [copiedAll, setCopiedAll] = useState(false);

  // Sentinel ref for infinite scrolling
  const sentinelRef = useRef<HTMLDivElement | null>(null);

  // Initial load
  useEffect(() => {
    handleSearch("Cristiano Ronaldo");
  }, []);

  const handleSearch = async (searchQuery: string) => {
    const q = searchQuery.trim();
    if (!q) return;

    setQuery(q);
    setIsLoading(true);
    setImages([]);
    setNextOffset(undefined);
    setHasMore(false);

    try {
      const res = await fetch("/api/google-scrape-images", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: q, offset: 0 }),
      });

      if (res.ok) {
        const data: GoogleImagesApiResponse = await res.json();
        setSearchDetail(data.detail);
        setImages(data.images || []);
        setNextOffset(data.nextOffset);
        setHasMore(data.hasMore);
      }
    } catch (err) {
      console.error("Search error:", err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLoadMore = useCallback(async () => {
    if (isLoadingMore || !hasMore || nextOffset === undefined) return;

    setIsLoadingMore(true);
    try {
      const res = await fetch("/api/google-scrape-images", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query, offset: nextOffset }),
      });

      if (res.ok) {
        const data: GoogleImagesApiResponse = await res.json();
        const newImages = data.images || [];

        // Deduplicate images
        setImages((prev) => {
          const existingUrls = new Set(prev.map((img) => img.url));
          const filtered = newImages.filter((img) => !existingUrls.has(img.url));
          return [...prev, ...filtered];
        });

        setNextOffset(data.nextOffset);
        setHasMore(data.hasMore && newImages.length > 0);
      }
    } catch (err) {
      console.error("Load more error:", err);
    } finally {
      setIsLoadingMore(false);
    }
  }, [isLoadingMore, hasMore, nextOffset, query]);

  // Infinite scroll trigger
  useEffect(() => {
    if (!sentinelRef.current) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasMore && !isLoadingMore && !isLoading) {
          handleLoadMore();
        }
      },
      { rootMargin: "300px" }
    );

    observer.observe(sentinelRef.current);
    return () => observer.disconnect();
  }, [handleLoadMore, hasMore, isLoadingMore, isLoading]);

  // Copy All Loaded Image URLs to clipboard
  const handleCopyAllImageUrls = () => {
    if (images.length === 0) return;
    const linksText = images.map((img, i) => `${i + 1}. ${img.url}`).join("\n");
    navigator.clipboard.writeText(linksText);
    setCopiedAll(true);
    setTimeout(() => setCopiedAll(false), 2500);
  };

  // Modal navigation
  const currentImageIndex = selectedImage
    ? images.findIndex((img) => img.id === selectedImage.id)
    : -1;

  const handleNavigateModal = (direction: "prev" | "next") => {
    if (currentImageIndex === -1) return;
    if (direction === "prev" && currentImageIndex > 0) {
      setSelectedImage(images[currentImageIndex - 1]);
    } else if (direction === "next" && currentImageIndex < images.length - 1) {
      setSelectedImage(images[currentImageIndex + 1]);
    }
  };

  return (
    <div className="min-h-screen bg-[#faf9f6] text-[#1c1917] flex flex-col selection:bg-stone-900 selection:text-white">
      {/* Sticky Navbar */}
      <Navbar
        viewMode={viewMode}
        onViewModeChange={setViewMode}
        totalImages={images.length}
        currentQuery={query}
      />

      <main className="flex-1 pb-16">
        {/* Unified Search Bar & Suggestions */}
        <section className="pt-4 pb-2">
          <SearchBar3D
            onSearch={handleSearch}
            isLoading={isLoading}
            initialQuery={query}
          />
        </section>

        {/* Factual Google/Wikipedia Detail Card (Overview of the search term) */}
        {searchDetail && !isLoading && (
          <GoogleDetailCard detail={searchDetail} />
        )}

        {/* Image Grid Section */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Action Bar Above Grid */}
          {images.length > 0 && (
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6 p-3.5 rounded-2xl bg-white border border-stone-200/90 shadow-3d-light">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
                <span className="text-xs font-bold text-stone-800">
                  Showing {images.length} Live Google & Web Results for &quot;{query}&quot;
                </span>
                <span className="text-[11px] text-stone-400 hidden sm:inline">
                  • Top links rendered with previews
                </span>
              </div>

              {/* Copy All Links Action */}
              <div className="flex items-center gap-2">
                <button
                  onClick={handleCopyAllImageUrls}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer ${
                    copiedAll
                      ? "bg-emerald-600 text-white"
                      : "bg-stone-900 hover:bg-black text-white"
                  }`}
                  title="Copy list of all direct image URLs"
                >
                  {copiedAll ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedAll ? `Copied ${images.length} Links!` : "Copy All Image URLs"}</span>
                </button>
              </div>
            </div>
          )}

          {/* Initial Loading Spinner */}
          {isLoading && (
            <div className="rounded-3xl bg-white border border-stone-200/90 p-16 text-center shadow-3d-light">
              <div className="w-16 h-16 rounded-2xl bg-emerald-50 border border-emerald-200 mx-auto flex items-center justify-center text-emerald-600 mb-4 animate-pulse">
                <Loader2 className="w-8 h-8 animate-spin" />
              </div>
              <h3 className="font-display font-bold text-xl text-stone-900 mb-2">
                Scraping Google & Web Images for &quot;{query}&quot;...
              </h3>
              <p className="text-xs sm:text-sm text-stone-500 max-w-md mx-auto">
                Opening top Google search links, downloading high-resolution image previews, and extracting direct image links.
              </p>
            </div>
          )}

          {/* Empty State */}
          {!isLoading && images.length === 0 && (
            <div className="rounded-3xl bg-white border border-stone-200/90 p-16 text-center shadow-3d-light">
              <div className="w-16 h-16 rounded-2xl bg-stone-100 mx-auto flex items-center justify-center text-stone-400 mb-4">
                <ImageIcon className="w-8 h-8" />
              </div>
              <h3 className="font-display font-bold text-lg text-stone-900 mb-1">
                No Images Found
              </h3>
              <p className="text-xs text-stone-500 max-w-md mx-auto mb-4">
                Try searching for another person, personality, object, or paste a direct website URL.
              </p>
            </div>
          )}

          {/* Render Images in 3D Bento or Equal Grid */}
          {!isLoading && images.length > 0 && (
            <div
              className={`grid gap-6 ${
                viewMode === "bento"
                  ? "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3"
                  : "grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4"
              }`}
            >
              {images.map((img, idx) => {
                const isLarge = viewMode === "bento" && (idx === 0 || idx === 7);
                return (
                  <ImageCard3D
                    key={img.id}
                    image={img}
                    index={idx}
                    onPreview={setSelectedImage}
                    isLarge={isLarge}
                  />
                );
              })}
            </div>
          )}

          {/* Infinite Scroll Sentinel / Load More Button */}
          {!isLoading && images.length > 0 && (
            <div className="mt-12 text-center">
              <div ref={sentinelRef} className="h-4" />

              {isLoadingMore ? (
                <div className="inline-flex items-center gap-2 px-6 py-3 rounded-2xl bg-white border border-stone-200 shadow-3d-light text-stone-700 text-xs font-bold animate-pulse">
                  <Loader2 className="w-4 h-4 animate-spin text-emerald-600" />
                  <span>Loading more Google images from the web...</span>
                </div>
              ) : hasMore ? (
                <button
                  onClick={handleLoadMore}
                  className="inline-flex items-center gap-2 px-6 py-3.5 rounded-2xl bg-stone-900 hover:bg-black text-white text-xs sm:text-sm font-bold shadow-3d-button active:translate-y-0.5 transition-all cursor-pointer"
                >
                  <ArrowDown className="w-4 h-4 text-emerald-400" />
                  <span>Load More Google Images</span>
                </button>
              ) : (
                <div className="text-xs font-semibold text-stone-400 py-4">
                  ✓ All top Google web image links have been loaded.
                </div>
              )}
            </div>
          )}
        </section>
      </main>

      {/* Lightbox Modal */}
      <ImageModal
        image={selectedImage}
        onClose={() => setSelectedImage(null)}
        onNavigate={handleNavigateModal}
        hasPrev={currentImageIndex > 0}
        hasNext={currentImageIndex < images.length - 1}
      />
    </div>
  );
}

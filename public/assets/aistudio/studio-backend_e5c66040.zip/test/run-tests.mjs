import assert from 'node:assert/strict';
import path from 'node:path';
import fs from 'node:fs';
import os from 'node:os';
import { fileURLToPath } from 'node:url';
import * as S from '../src/index.mjs';
import { contrastRatio } from '../src/color.mjs';

const dir = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'library');
let pass = 0, fail = 0; const failures = [];
const t = async (name, fn) => { try { await fn(); pass++; console.log('  ok  ' + name); } catch (e) { fail++; failures.push(name); console.log('  FAIL ' + name + '\n       ' + (e.message || e)); } };
const lib = S.loadLibrary(dir);

console.log('Library'); 
await t('cross references valid', () => assert.deepEqual(S.checkLibrary(lib), []));
await t('counts', () => { assert.ok(lib.raw.styles.length >= 24); assert.ok(lib.raw.effects.effects.length >= 40); assert.ok(lib.raw.palettes.length >= 24); assert.ok(lib.raw.typography.pairs.length >= 20); assert.ok(lib.raw.recipes.length >= 19); });
await t('every palette text contrasts >=4.5 with bg or surface', () => { for (const p of lib.raw.palettes) { const r = Math.max(contrastRatio(p.colors[0], p.colors[4]), contrastRatio(p.colors[1], p.colors[4])); assert.ok(r >= 4.5, p.id + ' ' + r.toFixed(2)); } });
await t('slices contain chosen items only', () => { const s = lib.slices({ recipe: 'thumbnail', style: 'neon-cyberpunk', palette: 'neon-night', fonts: 'hi-rajdhani', layout: 'text-left-subject-right', effects: ['sparkles'] }); assert.equal(s.style.id, 'neon-cyberpunk'); assert.ok(s.effects.length > 3); assert.ok(s.motifs.find((m) => m.id === 'sparkle')); });
await t('catalog is compact (<14KB)', () => assert.ok(JSON.stringify(lib.catalog()).length < 14000, String(JSON.stringify(lib.catalog()).length)));

console.log('Intent');
const cases = [
  ['ek YouTube thumbnail banao AI par', 'generate'], ['Hindi me poster bana do diwali ka', 'generate'], ['एक लोगो बनाओ मेरी दुकान के लिए', 'generate'],
  ['generate an image of a sunset poster', 'generate'], ['मुझे इमेज जनरेट करनी है', 'generate'], ['make a wallpaper for my phone', 'generate'], ['इंस्टाग्राम पोस्ट बना दो', 'generate'],
  ['Taj Mahal ki photos dikhao', 'search'], ['find images of Virat Kohli', 'search'], ['सचिन की फोटो ढूंढ के दो', 'search'], ['show me pics of red panda', 'search'],
  ['python me list kya hota hai', 'none'], ['aaj ka mausam kaisa hai', 'none'], ['thanks bhai', 'none'], ['What is the capital of France?', 'none'],
];
for (const [m, exp] of cases) await t(`"${m}" → ${exp}`, () => assert.equal(S.detectIntent(m).intent, exp, JSON.stringify(S.detectIntent(m))));
await t('edit: remove background with upload', () => assert.equal(S.detectIntent('is photo ka background remove karo', [{ type: 'image/png' }]).intent, 'edit'));
await t('size parse + presets', () => { assert.deepEqual(S.parseCustomSize('1200 x 628'), { w: 1200, h: 628 }); assert.deepEqual(S.parseCustomSize('9000x100'), { w: 4096, h: 200 }); assert.equal(S.inferSizePreset('youtube thumbnail'), 'yt-thumbnail'); assert.equal(S.inferSizePreset('instagram story'), 'story-reel'); });
await t('language', () => { assert.equal(S.detectLanguage('मुझे पोस्टर चाहिए'), 'hi'); assert.equal(S.detectLanguage('poster banao yaar'), 'hinglish'); assert.equal(S.detectLanguage('make a poster'), 'en'); });
await t('popup text localised', () => assert.ok(S.POPUP_TEXT.hi.body.includes('जनरेट')));

console.log('Questions');
await t('asks size+style+text when nothing is known', () => { const i = S.detectIntent('poster banao'); const q = S.pickQuestions({ message: 'poster banao', intent: i, library: lib }); assert.deepEqual(q.map((x) => x.id), ['size', 'style', 'text']); assert.ok(q[0].options.find((o) => o.id === 'custom')); });
await t('skips size when platform named, text when quoted', () => { const m = 'youtube thumbnail banao "AI se kamai" neon style'; const q = S.pickQuestions({ message: m, intent: S.detectIntent(m), library: lib }); assert.equal(q.length, 0); });
await t('asks photo question with upload', () => { const m = 'logo banao'; const q = S.pickQuestions({ message: m, intent: S.detectIntent(m), attachments: [{ type: 'image/png' }], library: lib }); assert.ok(q.find((x) => x.id === 'photo')); });
await t('max 4 questions, Hindi labels', () => { const m = 'पोस्टर बनाओ'; const q = S.pickQuestions({ message: m, intent: S.detectIntent(m), attachments: [{ type: 'image/png' }], library: lib }); assert.ok(q.length <= 4); assert.ok(/[\u0900-\u097F]/.test(q[0].question)); });
await t('resolveAnswers custom size', () => { const r = S.resolveAnswers({ message: 'poster', answers: { size: 'custom', sizeCustom: '1200x628' }, intent: { recipe: 'poster' }, library: lib }); assert.deepEqual([r.size.w, r.size.h], [1200, 628]); });

console.log('Validator');
const good = (w, h) => `<!DOCTYPE html><html><head><link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet"><style>body{margin:0}#canvas{position:relative;width:${w}px;height:${h}px;overflow:hidden;font-family:'Poppins',sans-serif}</style></head><body><div id="canvas"><img src="{{asset:a1}}"><div style="background:url({{asset:a1}})">हिंदी</div></div></body></html>`;
await t('good html passes', () => { const v = S.validateComposition(good(1280, 720), { width: 1280, height: 720, assets: ['a1'], language: 'hi' }); assert.ok(v.ok, JSON.stringify(v.issues)); });
await t('detects wrong size / script / external / unknown asset', () => {
  const bad = good(1280, 720).replace('</body>', '<script>fetch("x")</script><img src="https://evil.com/a.png"></body>').replace('{{asset:a1}}', '{{asset:zz}}');
  const v = S.validateComposition(bad, { width: 1000, height: 1000, assets: ['a1'] }); const codes = v.issues.map((i) => i.code);
  for (const c of ['bad-size', 'script', 'external-resource', 'unknown-asset', 'forbidden-api']) assert.ok(codes.includes(c), c + ' missing: ' + codes);
});
await t('stripFences', () => assert.ok(S.stripFences('Here:\n```html\n<!DOCTYPE html><html></html>\n```\nenjoy').startsWith('<!DOCTYPE')));
await t('extractJson', () => assert.equal(S.extractJson('sure ```json\n{"a":1}\n``` ok').a, 1));

console.log('Plan normalisation');
const resolved = { size: { w: 1280, h: 720, preset: 'yt-thumbnail' }, style: null, text: null, photo: null, web: null, language: 'hi' };
await t('fixes bad ids, forces user size, swaps non-Devanagari font, caps/blocks assets', () => {
  const raw = { recipe: 'nope', style: 'nope', palette: 'x', fonts: 'condensed-bebas', layout: 'zzz', size: { w: 10, h: 10 }, language: 'hi', text: { title: 'AI से कमाई' },
    assets: [{ id: 'a1', source: 'search', query: 'Hawa Mahal Jaipur' }, { id: 'a2', source: 'search', query: 'nude model' }, { id: 'a3', source: 'upload', uploadId: 'missing' }, { id: 'a4 ?!', source: 'search', query: 'Sachin Tendulkar cricketer' }] };
  const { plan, warnings } = S.normalizePlan(raw, { library: lib, resolved, intent: { recipe: 'thumbnail' }, uploads: [] });
  assert.equal(plan.recipe, 'thumbnail'); assert.deepEqual([plan.size.w, plan.size.h], [1280, 720]);
  assert.ok(lib.idx.fonts[plan.fonts].scripts.includes('devanagari'));
  assert.deepEqual(plan.assets.map((a) => a.id), ['a1', 'a4']); assert.ok(warnings.find((w) => w.code === 'blocked-query'));
  assert.ok(lib.idx.layouts[plan.layout] && lib.idx.styles[plan.style] && lib.idx.palettes[plan.palette]);
});
await t('refusal passes through', () => assert.ok(S.normalizePlan({ refuse: { reason: 'private person' } }, { library: lib, resolved, intent: {} }).refused));

console.log('Thinking summary');
await t('analysis line is built from facts (no canned text)', () => {
  const l = new S.ThinkingLog('en'); const a = l.analysis({ name: 'photo.jpg', width: 1200, height: 1600, orientation: 'portrait', bgUniform: true, bgColor: '#e5e5e5', brightness: 0.8, dominant: ['#2b3a67'], hasAlpha: false });
  for (const frag of ['photo.jpg', '1200×1600', 'portrait', '#e5e5e5', 'bright', '#2b3a67']) assert.ok(a.text.includes(frag), frag + ' in ' + a.text);
  const b = new S.ThinkingLog('en').analysis({ name: 'other.png', width: 400, height: 400, orientation: 'square', bgUniform: false, brightness: 0.2, dominant: ['#000000'] });
  assert.notEqual(a.text, b.text); assert.ok(b.text.includes('low resolution') && b.text.includes('busy'));
});
await t('Hindi + failure wording + search', () => { const l = new S.ThinkingLog('hi'); assert.ok(l.analysisFailed('x.mp4').text.includes('x.mp4')); assert.ok(l.search('Taj Mahal', 0).text.includes('Taj Mahal')); });

console.log('SSRF');
await t('private IPs blocked', async () => { for (const u of ['http://127.0.0.1/a', 'http://10.0.0.5/a', 'http://169.254.169.254/latest', 'http://[::1]/a', 'file:///etc/passwd', 'http://localhost/x']) await assert.rejects(() => S.assertPublicUrl(u), undefined, u); });
await t('hostname resolving to private blocked, public allowed', async () => { await assert.rejects(() => S.assertPublicUrl('http://evil.example/x', async () => [{ address: '10.1.2.3' }])); await S.assertPublicUrl('https://upload.wikimedia.org/a.jpg', async () => [{ address: '93.184.216.34' }]); });
await t('proxy rejects non-image and revalidates redirects', async () => {
  const lookup = async () => [{ address: '93.184.216.34' }];
  const f1 = async () => ({ status: 200, ok: true, headers: new Map([['content-type', 'text/html']]), arrayBuffer: async () => new ArrayBuffer(4) });
  await assert.rejects(() => S.fetchImageSafe('https://a.com/x', { fetchImpl: f1, lookup }), /allowed image/);
  let n = 0; const f2 = async () => (++n === 1 ? { status: 302, ok: false, headers: new Map([['location', 'http://127.0.0.1/secret']]) } : { status: 200, ok: true, headers: new Map([['content-type', 'image/png']]), arrayBuffer: async () => new ArrayBuffer(4) });
  await assert.rejects(() => S.fetchImageSafe('https://a.com/x', { fetchImpl: f2, lookup: async (h) => (h === '127.0.0.1' ? [{ address: '127.0.0.1' }] : lookup()) }), /Private/);
});

console.log('Keystore + LLM client');
await t('keystore encrypts and round-trips; wrong secret fails', () => {
  const d = fs.mkdtempSync(path.join(os.tmpdir(), 'ks-')); const ks = S.createKeystore({ dir: d, secret: 'x'.repeat(32) }); ks.save({ provider: 'xai', model: 'm', apiKey: 'sk-test-1234567890' });
  assert.equal(ks.load().apiKey, 'sk-test-1234567890'); assert.equal(ks.status().keyLast4, '7890');
  assert.ok(!fs.readFileSync(path.join(d, 'llm-config.enc.json'), 'utf8').includes('sk-test'));
  assert.throws(() => S.createKeystore({ dir: d, secret: 'y'.repeat(32) }).load()); ks.clear(); assert.equal(ks.status().configured, false);
  assert.throws(() => S.createKeystore({ dir: d, secret: 'short' }));
});
await t('testLlmConfig success / bad key / unknown model', async () => {
  const mk = (st, body) => async () => ({ ok: st < 400, status: st, statusText: 'x', text: async () => JSON.stringify(body) });
  const routeFetch = async (url, init) => url.endsWith('/models') ? { ok: true, status: 200, text: async () => JSON.stringify({ data: [{ id: 'good-model' }] }) } : { ok: true, status: 200, text: async () => JSON.stringify({ choices: [{ message: { content: 'ok' } }] }) };
  assert.ok((await S.testLlmConfig({ provider: 'xai', apiKey: 'k', model: 'good-model' }, routeFetch)).ok);
  assert.equal((await S.testLlmConfig({ provider: 'xai', apiKey: 'k', model: 'bad-model' }, routeFetch)).ok, false);
  const r = await S.testLlmConfig({ provider: 'groq', apiKey: 'k', model: 'm' }, mk(401, { error: { message: 'Invalid API key' } })); assert.equal(r.ok, false); assert.ok(r.steps.at(-1).detail.includes('Invalid API key'));
});

console.log('Orchestrator (mock LLM + mock client)');
const mkHtml = (w, h, bad) => `<!DOCTYPE html><html><head><link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet"><style>body{margin:0}#canvas{position:relative;width:${bad ? 1 : w}px;height:${h}px;overflow:hidden;--u:${w / 100}px;font-family:'Poppins',sans-serif}</style></head><body><div id="canvas"><img src="{{asset:a1}}"><h1>AI से कमाई</h1></div></body></html>`;
function mockLlm({ failFirstCompose = false, plan }) { let composeCalls = 0; return { async chat(msgs) { const sys = msgs[0].content; if (sys.includes('Creative Director')) return '```json\n' + JSON.stringify(plan) + '\n```'; composeCalls++; const sz = /(\d+)px × (\d+)px/.exec(sys); return '```html\n' + mkHtml(+sz[1], +sz[2], failFirstCompose && composeCalls === 1) + '\n```'; }, get composeCalls() { return composeCalls; } }; }
const plan1 = { brief: { goal: 'drive clicks on an AI-earning video' }, rationale: 'High-contrast bold style because thumbnails are judged at tiny size.', recipe: 'thumbnail', style: 'bold-yt-thumbnail', palette: 'money-red', fonts: 'hi-bold-poppins', layout: 'text-left-subject-right', language: 'hi', text: { title: 'AI से कमाई' }, assets: [{ id: 'a1', source: 'upload', uploadId: 'u1', role: 'subject', removeBackground: true, adjust: { brightness: 1.1 } }, { id: 'a2', source: 'search', query: 'laptop desk', role: 'decor' }] };
await t('end-to-end: events, summary, repair loop, asset embedding', async () => {
  const events = []; const llm = mockLlm({ failFirstCompose: true, plan: plan1 });
  const res = await S.runStudioJob({ message: 'ek youtube thumbnail banao', intent: S.detectIntent('ek youtube thumbnail banao'), answers: {}, attachments: [{ id: 'u1', name: 'me.jpg', type: 'image/jpeg', facts: { width: 1200, height: 1600, orientation: 'portrait', bgUniform: true, bgColor: '#dddddd', brightness: 0.6, dominant: ['#112233'] } }] },
    { llm, library: lib, emit: (e) => events.push(e), searchImages: async () => [], clientTask: async (task, p) => p.assetId === 'a1' ? { dataUrl: 'data:image/png;base64,AAAA', width: 800, height: 1000, method: 'ai', facts: { hasAlpha: true } } : { error: 'x' } });
  assert.ok(res.ok, JSON.stringify(res.warnings)); assert.equal(llm.composeCalls, 2, 'repair loop ran'); assert.ok(res.html.includes('data:image/png;base64,AAAA')); assert.ok(!res.html.includes('{{asset:'));
  const pcts = events.filter((e) => e.type === 'progress').map((e) => e.percent); assert.deepEqual(pcts, [...pcts].sort((a, b) => a - b)); assert.equal(pcts.at(-1), 100);
  const texts = res.summary.map((s) => s.text).join('\n'); for (const f of ['me.jpg', '1200×1600', 'AI model', 'laptop desk', 'bold-yt-thumbnail'.length ? 'Bold YouTube Thumbnail' : '']) assert.ok(texts.includes(f), f + '\n' + texts);
  assert.ok(res.summary.find((s) => s.kind === 'check' && /fixed/.test(s.text)), 'check line mentions the fix');
  assert.equal(res.width, 1280); assert.equal(res.height, 720);
});
await t('refusal path', async () => { const ev = []; const r = await S.runStudioJob({ message: 'x', intent: { recipe: 'poster', lang: 'en' }, answers: {}, attachments: [] }, { llm: mockLlm({ plan: { refuse: { reason: 'private person' } } }), library: lib, emit: (e) => ev.push(e), searchImages: async () => [], clientTask: async () => ({}) }); assert.ok(r.refused); assert.ok(ev.find((e) => e.type === 'refused')); });
await t('user custom size is honoured', async () => { const r = await S.runStudioJob({ message: 'poster 1200x628', intent: S.detectIntent('poster 1200x628'), answers: { size: 'custom', sizeCustom: '1200x628' }, attachments: [] }, { llm: mockLlm({ plan: { ...plan1, assets: [] } }), library: lib, emit: () => {}, searchImages: async () => [], clientTask: async () => ({}) }); assert.deepEqual([r.width, r.height], [1200, 628]); });

console.log('Router (stub express)');
await t('registers routes; intent route returns popup and leaks nothing', async () => {
  const routes = []; const R = () => { const o = {}; for (const m of ['get', 'post', 'delete']) o[m] = (p, ...h) => routes.push({ m, p, h }); return o; };
  const express = { Router: R, json: () => (_q, _s, n) => n && n() };
  const ks = S.createKeystore({ dir: fs.mkdtempSync(path.join(os.tmpdir(), 'ks-')), secret: 'z'.repeat(32) });
  S.createStudioRouter({ express, library: lib, keystore: ks, adminToken: 'tok', imageSearchUrl: '' });
  const paths = routes.map((r) => r.m + ' ' + r.p); for (const p of ['post /api/studio/intent', 'post /api/studio/jobs', 'get /api/studio/jobs/:id/events', 'get /api/studio/img-proxy', 'post /api/studio/admin/llm']) assert.ok(paths.includes(p), p);
  assert.ok(!paths.some((p) => /librar|styles|effects|templates/i.test(p)), 'no library routes');
  const h = routes.find((r) => r.p === '/api/studio/intent').h.at(-1); let out; h({ body: { message: 'poster bana do' } }, { json: (o) => (out = o) });
  assert.equal(out.intent, 'generate'); assert.ok(out.popup.yes); assert.ok(!('reasons' in out));
  const admin = routes.find((r) => r.p === '/api/studio/admin/status').h[0]; let code = 0; admin({ get: () => 'wrong' }, { status: (c) => ({ json: () => (code = c) }) }, () => {}); assert.equal(code, 401);
});

console.log(`\n${pass} passed, ${fail} failed`); if (fail) { console.log(failures.join('\n')); process.exit(1); }

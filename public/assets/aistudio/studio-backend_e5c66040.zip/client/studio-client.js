// Browser helper for the Creative Studio pipeline (framework-agnostic ES module). NOT yet tested in a real browser.
// Responsibilities: call backend endpoints, run client tasks (image analysis, download via proxy, background removal, adjustments),
// and stream job events to your UI.   The design library never reaches the browser.

const J = (r) => r.json();
const post = (url, body) => fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }).then(J);

export const studioApi = {
  intent: (message, attachments = []) => post('/api/studio/intent', { message, attachments: attachments.map(({ id, name, type }) => ({ id, name, type })) }),
  questions: (message, attachments = [], answers = {}) => post('/api/studio/questions', { message, attachments: attachments.map(({ id, name, type }) => ({ id, name, type })), answers }),
  startJob: (message, answers, attachments) => post('/api/studio/jobs', { message, answers, attachments: attachments.map(({ id, name, type, facts }) => ({ id, name, type, facts })) }),
  cancel: (jobId) => post(`/api/studio/jobs/${jobId}/cancel`, {}),
};

/** Chat box size: keeps the exact aspect ratio inside a small box (never full screen). */
export function previewBox(w, h, maxW = 320, maxH = 380) { const k = Math.min(maxW / w, maxH / h, 1); return { width: Math.round(w * k), height: Math.round(h * k), scale: k }; }

/** Stream job events. handlers: { progress, step, result, error, refused }. Returns {close()} */
export function watchJob(jobId, handlers, getUpload) {
  const es = new EventSource(`/api/studio/jobs/${jobId}/events`);
  es.onmessage = async (m) => {
    const e = JSON.parse(m.data);
    if (e.type === 'client_task') {
      let result;
      try { result = await runClientTask(e.task, e.payload, getUpload); } catch (err) { result = { error: String(err.message || err).slice(0, 120) }; }
      await post(`/api/studio/jobs/${jobId}/client-result`, { taskId: e.taskId, result });
      return;
    }
    handlers[e.type] && handlers[e.type](e);
    if (e.type === 'result' || e.type === 'error' || e.type === 'refused') es.close();
  };
  es.onerror = () => { /* EventSource retries; backend replays buffered events */ };
  return { close: () => es.close() };
}

/** Elapsed timer + percent for the corner overlay: smooth the backend's stage percent. */
export function createProgressDisplay(onTick) {
  let target = 0, shown = 0, start = performance.now(), raf;
  const loop = () => { shown += (target - shown) * 0.08; if (target - shown < 0.3) shown = target; onTick({ percent: Math.min(99.9, shown) | 0, seconds: ((performance.now() - start) / 1000) | 0 }); raf = requestAnimationFrame(loop); };
  raf = requestAnimationFrame(loop);
  return { set: (p) => { target = Math.max(target, p); }, finish: () => { target = 100; shown = 100; onTick({ percent: 100, seconds: ((performance.now() - start) / 1000) | 0 }); cancelAnimationFrame(raf); }, stop: () => cancelAnimationFrame(raf) };
}

// ---------------- client tasks ----------------
async function runClientTask(task, p, getUpload) {
  if (task !== 'prepare_asset') return { error: 'unknown task' };
  let img, chosen = null;
  if (p.source === 'upload') { const f = getUpload(p.uploadId); if (!f) return { error: 'upload missing' }; img = await loadImage(await fileToDataUrl(f)); }
  else {
    for (const c of p.candidates || []) { try { img = await loadImage('/api/studio/img-proxy?url=' + encodeURIComponent(c.url || c.thumbnail)); chosen = c; break; } catch { /* next */ } }
    if (!img) return { error: 'no candidate could be loaded' };
  }
  let canvas = drawScaled(img, p.maxSize || 1600);
  const facts = analyzeCanvas(canvas, p.source === 'upload' ? (getUpload(p.uploadId).name) : (chosen && chosen.title) || 'web image');
  let method = 'none';
  if (p.removeBackground) { const r = await removeBackgroundCanvas(canvas); canvas = r.canvas; method = r.method; }
  if (p.adjust && Object.keys(p.adjust).length) canvas = adjustCanvas(canvas, p.adjust);
  return { dataUrl: canvas.toDataURL('image/png'), width: canvas.width, height: canvas.height, facts: { ...facts, hasAlpha: facts.hasAlpha || method !== 'none' }, method, chosen };
}

export const fileToDataUrl = (f) => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(f); });
export const loadImage = (src) => new Promise((res, rej) => { const i = new Image(); i.crossOrigin = 'anonymous'; i.onload = () => res(i); i.onerror = () => rej(new Error('image load failed')); i.src = src; });
function drawScaled(img, maxSize) { const k = Math.min(1, maxSize / Math.max(img.width, img.height)); const c = document.createElement('canvas'); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k); c.getContext('2d').drawImage(img, 0, 0, c.width, c.height); return c; }

// ---------------- analysis (real measurements; the LLM only reads these) ----------------
export function analyzeCanvas(canvas, name) {
  const W = canvas.width, H = canvas.height, s = document.createElement('canvas'); const k = Math.min(1, 96 / Math.max(W, H)); s.width = Math.max(1, Math.round(W * k)); s.height = Math.max(1, Math.round(H * k));
  const ctx = s.getContext('2d', { willReadFrequently: true }); ctx.drawImage(canvas, 0, 0, s.width, s.height);
  const d = ctx.getImageData(0, 0, s.width, s.height).data; let sum = 0, n = 0, alpha = false; const bins = new Map();
  for (let i = 0; i < d.length; i += 4) { if (d[i + 3] < 250) alpha = true; if (d[i + 3] < 20) continue; const l = (0.2126 * d[i] + 0.7152 * d[i + 1] + 0.0722 * d[i + 2]) / 255; sum += l; n++; const key = ((d[i] >> 5) << 6) | ((d[i + 1] >> 5) << 3) | (d[i + 2] >> 5); bins.set(key, (bins.get(key) || 0) + 1); }
  const dominant = [...bins.entries()].sort((a, b) => b[1] - a[1]).slice(0, 3).map(([k2]) => '#' + [((k2 >> 6) & 7), ((k2 >> 3) & 7), (k2 & 7)].map((v) => Math.min(255, v * 36 + 18).toString(16).padStart(2, '0')).join(''));
  // background uniformity from the border ring
  const ring = []; const sw = s.width, sh = s.height; const px = (x, y) => { const i = (y * sw + x) * 4; return [d[i], d[i + 1], d[i + 2]]; };
  for (let x = 0; x < sw; x++) { ring.push(px(x, 0), px(x, sh - 1)); } for (let y = 0; y < sh; y++) { ring.push(px(0, y), px(sw - 1, y)); }
  const avg = ring.reduce((a, c) => [a[0] + c[0], a[1] + c[1], a[2] + c[2]], [0, 0, 0]).map((v) => v / ring.length);
  const dev = ring.reduce((a, c) => a + Math.hypot(c[0] - avg[0], c[1] - avg[1], c[2] - avg[2]), 0) / ring.length;
  const hex = '#' + avg.map((v) => Math.round(v).toString(16).padStart(2, '0')).join('');
  return { name, width: W, height: H, orientation: Math.abs(W - H) / Math.max(W, H) < 0.06 ? 'square' : W > H ? 'landscape' : 'portrait', hasAlpha: alpha, brightness: n ? +(sum / n).toFixed(2) : 0, dominant, bgUniform: dev < 28, bgColor: hex };
}
export async function analyzeFile(file) { const img = await loadImage(await fileToDataUrl(file)); return analyzeCanvas(drawScaled(img, 600), file.name); }

/** Video: sample N frames, tile into ONE contact sheet (with time labels), return facts + sheet dataURL. */
export async function analyzeVideoFile(file, frames = 12, cols = 4) {
  const url = URL.createObjectURL(file), v = document.createElement('video'); v.muted = true; v.src = url; await new Promise((r, j) => { v.onloadedmetadata = r; v.onerror = j; });
  const dur = v.duration || 0, tw = 240, th = Math.round((tw * v.videoHeight) / v.videoWidth) || 135, rows = Math.ceil(frames / cols);
  const sheet = document.createElement('canvas'); sheet.width = tw * cols; sheet.height = th * rows; const g = sheet.getContext('2d'); g.fillStyle = '#000'; g.fillRect(0, 0, sheet.width, sheet.height); const times = [];
  for (let i = 0; i < frames; i++) { const t = Math.min(dur - 0.05, (dur * (i + 0.5)) / frames); await new Promise((r) => { v.onseeked = r; v.currentTime = t; }); const x = (i % cols) * tw, y = Math.floor(i / cols) * th; g.drawImage(v, x, y, tw, th); g.fillStyle = 'rgba(0,0,0,.65)'; g.fillRect(x, y, 54, 18); g.fillStyle = '#fff'; g.font = '12px sans-serif'; g.fillText(fmt(t), x + 4, y + 13); times.push(+t.toFixed(1)); }
  URL.revokeObjectURL(url);
  return { name: file.name, kind: 'video', durationSec: +dur.toFixed(1), frameTimes: times, contactSheet: sheet.toDataURL('image/jpeg', 0.8), ...analyzeCanvas(sheet, file.name), width: v.videoWidth, height: v.videoHeight };
}
const fmt = (t) => `${Math.floor(t / 60)}:${String(Math.floor(t % 60)).padStart(2, '0')}`;

// ---------------- background removal + adjustments ----------------
export async function removeBackgroundCanvas(canvas) {
  try {
    const mod = await import('https://cdn.jsdelivr.net/npm/@imgly/background-removal@1.5.5/+esm');
    const blob = await new Promise((r) => canvas.toBlob(r, 'image/png')); const out = await mod.removeBackground(blob);
    const img = await loadImage(URL.createObjectURL(out)); const c = document.createElement('canvas'); c.width = img.width; c.height = img.height; c.getContext('2d').drawImage(img, 0, 0); return { canvas: c, method: 'ai' };
  } catch { return { canvas: removeBackgroundSimple(canvas), method: 'simple' }; }
}
export function removeBackgroundSimple(canvas, tol = 48) {
  const W = canvas.width, H = canvas.height, c = document.createElement('canvas'); c.width = W; c.height = H; const ctx = c.getContext('2d', { willReadFrequently: true }); ctx.drawImage(canvas, 0, 0);
  const im = ctx.getImageData(0, 0, W, H), p = im.data, at = (x, y) => (y * W + x) * 4;
  const cs = [at(0, 0), at(W - 1, 0), at(0, H - 1), at(W - 1, H - 1)].map((i) => [p[i], p[i + 1], p[i + 2]]); const bg = cs.reduce((a, b) => [a[0] + b[0] / 4, a[1] + b[1] / 4, a[2] + b[2] / 4], [0, 0, 0]);
  const seen = new Uint8Array(W * H), st = []; for (let x = 0; x < W; x++) st.push(x, 0, x, H - 1); for (let y = 0; y < H; y++) st.push(0, y, W - 1, y);
  while (st.length) { const y = st.pop(), x = st.pop(); if (x < 0 || y < 0 || x >= W || y >= H) continue; const k = y * W + x; if (seen[k]) continue; const i = k * 4; if (Math.hypot(p[i] - bg[0], p[i + 1] - bg[1], p[i + 2] - bg[2]) > tol) continue; seen[k] = 1; p[i + 3] = 0; st.push(x + 1, y, x - 1, y, x, y + 1, x, y - 1); }
  ctx.putImageData(im, 0, 0); return c;
}
export function adjustCanvas(canvas, { brightness = 1, contrast = 1, saturate = 1, blur = 0 } = {}) {
  const c = document.createElement('canvas'); c.width = canvas.width; c.height = canvas.height; const g = c.getContext('2d');
  g.filter = `brightness(${brightness}) contrast(${contrast}) saturate(${saturate})${blur ? ` blur(${blur}px)` : ''}`; g.drawImage(canvas, 0, 0); return c;
}

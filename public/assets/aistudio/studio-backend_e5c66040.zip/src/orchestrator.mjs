import { ThinkingLog } from './thinking.mjs';
import { resolveAnswers } from './questions.mjs';
import { extractJson, normalizePlan, fontLinkFor } from './plan.mjs';
import { validateComposition, stripFences } from './validate.mjs';

const fill = (tpl, map) => Object.entries(map).reduce((s, [k, v]) => s.split(`{{${k}}}`).join(String(v)), tpl);
const PIXEL = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';

/**
 * job: { message, intent, answers, attachments:[{id,name,type,facts}] }
 * deps: { llm, library, searchImages, clientTask(task,payload), emit(evt), now() }
 */
export async function runStudioJob(job, deps) {
  const { llm, library, searchImages, clientTask, emit } = deps;
  const now = deps.now || (() => Date.now());
  const t0 = now();
  const lang = job.intent && job.intent.lang === 'hi' ? 'hi' : 'en';
  const log = new ThinkingLog(lang);
  const sources = [], warnings = [];
  const progress = (percent, stage, label) => emit({ type: 'progress', percent, stage, label, elapsedMs: now() - t0 });
  const step = (s) => { if (s) emit({ type: 'step', step: s }); return s; };

  progress(2, 'understand', 'Understanding');
  const attachments = job.attachments || [];
  for (const a of attachments) {
    if (a.facts) step(log.analysis({ name: a.name, ...a.facts }));
    else step(log.analysisFailed(a.name || a.id));
  }

  // ---- 1. PLAN ----
  const resolved = resolveAnswers({ message: job.message, answers: job.answers || {}, intent: job.intent, library });
  const catalog = library.catalog();
  const plannerSystem = library.raw.instructions.planner + '\n\n# CATALOG\n' + JSON.stringify(catalog);
  const plannerUser = JSON.stringify({ request: job.message, language: resolved.language, userAnswers: resolved, uploads: attachments.map((a) => ({ id: a.id, name: a.name, facts: a.facts || null })), recipeHint: job.intent.recipe || null });
  let rawPlan, lastErr;
  for (let i = 0; i < 2 && !rawPlan; i++) {
    try { const out = await llm.chat([{ role: 'system', content: plannerSystem }, { role: 'user', content: plannerUser + (i ? '\n\nReturn ONLY the JSON object.' : '') }], { temperature: 0.5, maxTokens: 2500 }); rawPlan = extractJson(out); } catch (e) { lastErr = e; }
  }
  if (!rawPlan) throw new Error('Planner failed: ' + (lastErr && lastErr.message));
  const norm = normalizePlan(rawPlan, { library, resolved, intent: job.intent, uploads: attachments });
  if (norm.refused) { emit({ type: 'refused', reason: String(norm.plan.refuse.reason || norm.plan.refuse).slice(0, 300) }); return { refused: true }; }
  const plan = norm.plan; warnings.push(...norm.warnings.map((w) => w.code + (w.detail ? ': ' + w.detail : '')));
  const recipe = library.recipe(plan.recipe), style = library.idx.styles[plan.style], layout = library.idx.layouts[plan.layout], palette = library.idx.palettes[plan.palette];
  step(log.understand({ recipeName: recipe.name, goal: plan.brief && plan.brief.goal, size: `${plan.size.w}×${plan.size.h}` }));
  step(log.decision(plan, { style: style.name, layout: layout.name, palette: palette.name }));
  progress(15, 'assets', 'Preparing assets');

  // ---- 2. ASSETS ----
  const manifest = [], assetData = {};
  const n = plan.assets.length;
  for (let i = 0; i < n; i++) {
    const a = plan.assets[i];
    try {
      let candidates = [];
      if (a.source === 'search') { candidates = await searchImages(a.query, { count: 6 }); if (!candidates.length) { step(log.search(a.query, 0)); step(log.skipAsset(a.id, 'no results')); continue; } }
      const res = await clientTask('prepare_asset', { assetId: a.id, source: a.source, uploadId: a.uploadId || null, candidates, removeBackground: !!a.removeBackground, adjust: a.adjust || {}, maxSize: Math.min(2000, Math.max(plan.size.w, plan.size.h)) });
      if (!res || res.error || !res.dataUrl) { if (a.source === 'search') step(log.search(a.query, candidates.length)); step(log.skipAsset(a.id, res && res.error)); continue; }
      const name = a.source === 'upload' ? ((attachments.find((x) => x.id === a.uploadId) || {}).name || a.uploadId) : (res.chosen && res.chosen.title) || a.query;
      if (a.source === 'search') { step(log.search(a.query, candidates.length, res.chosen || candidates[0])); const c = res.chosen || candidates[0]; if (c) sources.push({ domain: c.sourceDomain, url: c.sourceUrl, title: c.title }); if (res.facts) step(log.analysis({ name, ...res.facts })); }
      if (a.removeBackground && res.method && res.method !== 'none') step(log.removeBg(name, res.method));
      step(log.adjust(name, a.adjust));
      assetData[a.id] = res.dataUrl;
      manifest.push({ id: a.id, name, role: a.role, width: res.width, height: res.height, hasAlpha: !!(res.facts && res.facts.hasAlpha) || !!(a.removeBackground && res.method && res.method !== 'none') });
    } catch (e) { step(log.skipAsset(a.id, String(e.message || e).slice(0, 80))); }
    progress(15 + Math.round(((i + 1) / Math.max(1, n)) * 30), 'assets', 'Preparing assets');
  }
  progress(45, 'compose', 'Designing');

  // ---- 3. COMPOSE ----
  const slices = library.slices(plan);
  if (plan.paletteOverride && slices.palette) { slices.palette = { ...slices.palette, colors: [...slices.palette.colors.slice(0, 4), plan.paletteOverride.text] }; }
  const U = +(plan.size.w / 100).toFixed(3);
  const composerSystem = fill(library.raw.instructions.composer, { W: plan.size.w, H: plan.size.h, U });
  const composerUser = JSON.stringify({ plan: { ...plan, assets: undefined }, canvas: { width: plan.size.w, height: plan.size.h, unit: U }, fontLink: fontLinkFor(library, plan), library: slices, assetManifest: manifest });
  const messages = [{ role: 'system', content: composerSystem }, { role: 'user', content: composerUser }];
  let html = stripFences(await llm.chat(messages, { temperature: 0.6, maxTokens: 7000 }));
  progress(85, 'validate', 'Checking');

  // ---- 4. VALIDATE + REPAIR ----
  const assetIds = manifest.map((m) => m.id);
  const fixed = [];
  let v = validateComposition(html, { width: plan.size.w, height: plan.size.h, assets: assetIds, language: plan.language });
  for (let r = 0; r < 2 && !v.ok; r++) {
    const errs = v.issues.filter((i) => i.severity === 'error');
    errs.forEach((e) => fixed.push(e.msg.replace(/\.$/, '')));
    const repairSys = fill(library.raw.instructions.repair, { ISSUES: errs.map((e) => `- [${e.code}] ${e.msg}`).join('\n') });
    html = stripFences(await llm.chat([...messages, { role: 'assistant', content: html }, { role: 'user', content: repairSys }], { temperature: 0.3, maxTokens: 7000 }));
    v = validateComposition(html, { width: plan.size.w, height: plan.size.h, assets: assetIds, language: plan.language });
  }
  if (!v.ok) warnings.push('validation-failed: ' + v.issues.filter((i) => i.severity === 'error').map((i) => i.code).join(','));
  warnings.push(...v.issues.filter((i) => i.severity === 'warn').map((i) => i.code));

  // ---- 5. RESOLVE ASSETS + FINAL CHECK ----
  html = html.replace(/\{\{asset:([a-z0-9_-]+)\}\}/gi, (_, id) => assetData[id] || PIXEL);
  const fin = validateComposition(html, { width: plan.size.w, height: plan.size.h, language: plan.language, preResolve: false });
  if (!fin.ok) warnings.push('final-check: ' + fin.issues.map((i) => i.code).join(','));
  step(log.check(v.checksPassed, [...new Set(fixed)].slice(0, 3), warnings.filter((w) => !/^(font-swapped|contrast-fixed)/.test(w)).slice(0, 3)));
  progress(100, 'done', 'Done');
  const seconds = Math.max(1, Math.round((now() - t0) / 1000));
  step(log.result(plan.size.w, plan.size.h, seconds));
  const result = { type: 'result', html, width: plan.size.w, height: plan.size.h, summary: log.steps, sources, warnings, plan: { recipe: plan.recipe, style: plan.style, palette: plan.palette, fonts: plan.fonts, layout: plan.layout, text: plan.text }, elapsedMs: now() - t0, ok: v.ok && fin.ok };
  emit(result);
  return result;
}

# Creative Studio backend (private design library + image pipeline)

Everything here runs **on your server**. The design library (`library/`) is read from disk by the backend and is
**never sent to the browser** — there is no route that returns it, and it must live outside `public/` and `dist/`.

## What it does
```
user message ──► POST /api/studio/intent      → {intent:'generate', popup:{title,body,yes,no}}   (rule-based, instant)
   tap [Generate] ─► POST /api/studio/questions → tappable questions (size, photo, style, text…)  (only what's missing)
   answers      ─► POST /api/studio/jobs        → {jobId}
                   GET  /api/studio/jobs/:id/events (SSE)
                        progress{percent,elapsedMs} · step{…thinking line…} · client_task{prepare_asset}
                        result{html,width,height,summary[],sources[]} · refused · error
                   POST /api/studio/jobs/:id/client-result   (browser answers client_task)
```
Pipeline inside a job: **plan** (LLM as creative director, picks style/palette/fonts/layout/assets from the library catalog) →
**assets** (web search via your Visual A-Z endpoint, download through the SSRF-guarded proxy, background removal + adjustments in the browser) →
**compose** (LLM writes HTML using only the chosen library slices) → **validate/repair** → **result**.

## Install into your Express app (e.g. the one in the zip you shared)
1. Copy this folder to your server project (e.g. `server/studio/`). Keep `library/` private.
2. `.env`: copy `.env.example` values.
3. In `server.ts`:
```ts
import express from 'express';
import { loadLibrary, createKeystore, createStudioRouter } from './studio/src/index.mjs';

const library  = loadLibrary(new URL('./studio/library', import.meta.url).pathname);
const keystore = createKeystore({ dir: process.env.STUDIO_DATA_DIR!, secret: process.env.STUDIO_SECRET! });
app.use(yourAuthMiddleware);                      // <- put your own login check BEFORE the studio router
app.use(createStudioRouter({ express, library, keystore, adminToken: process.env.ADMIN_TOKEN!, imageSearchUrl: process.env.IMAGE_SEARCH_URL }));
```
4. Frontend: `import { studioApi, watchJob, previewBox, createProgressDisplay, analyzeFile, analyzeVideoFile } from './studio-client.js'` (see `client/`).

## Saving your Grok API key (tests it first)
Header `x-admin-token: $ADMIN_TOKEN` on every admin call. The key is stored AES-256-GCM encrypted; it is never returned.
```
POST /api/studio/admin/llm/models  {"provider":"xai","apiKey":"…"}                → lists models your key can use
POST /api/studio/admin/llm         {"provider":"xai","apiKey":"…","model":"<one from the list>"}   → tests auth + 1 tiny chat, saves only if both pass
POST same with "testOnly":true     → test without saving
GET  /api/studio/admin/status      → {configured, provider, model, keyLast4}
DELETE /api/studio/admin/llm
```
`provider` is `xai` (Grok, api.x.ai) or `groq` (Groq, api.groq.com) — they are different companies; choose the one your key belongs to.
Both are OpenAI-compatible. Model names are NOT hard-coded: you pick one from the list. If your provider rejects `max_tokens`, pass `"tokenParam":"max_completion_tokens"`.

## UI contract (what the app must show) — style it with your app's own tokens
1. **Popup** on `intent.popup`: title/body/[yes]/[no]. [yes] → call `/questions`. If `intent === 'maybe_generate'` do nothing.
2. **Questions**: render with your existing question UI. Each item: `{id,type,question,options[{id,label}],allowCustomText,default}`. Always add a "Generate now" button that skips the rest. Collect `answers = {size:'preset:yt-thumbnail'|'custom', sizeCustom:'1200x628', style:'auto'|'style:…', text, photo, web, language}`.
3. **Generating box (in chat, small)**: `previewBox(w,h)` → exact aspect ratio, max 320×380 px. Top-right corner chip: `42% · 0:07` driven by `createProgressDisplay` (`set(e.percent)` on `progress` events). Show the `step` events as the Thinking section lines (real, in order).
4. **Result**: replace the box content with the HTML rendered in `<iframe sandbox="allow-same-origin" srcdoc=…>` scaled by `previewBox().scale`; tap → full-screen viewer; buttons Download PNG / Regenerate / Change style. (Render PNG with `html-to-image` or by drawing the iframe document — HTML is script-free by validation.)
5. **Thinking section**: show `result.summary[]` (`{kind,text}`) — it is built from real logs. Never show saved/canned text.

## Tests
`npm test` (Node 18+, no dependencies) — 46 checks: library integrity, intent (EN/Hinglish/Hindi), questions, validator, plan normaliser, thinking summary, SSRF guard, keystore encryption, LLM key test, end-to-end pipeline with a mock LLM, router wiring.
What is NOT tested here: real Grok/Groq calls, the browser client (`client/studio-client.js` passes a syntax check only), Express runtime, SSE through your proxy/CDN (disable buffering).

## Security notes
- Add your own auth middleware before the studio router; rate limits included are per-IP basics.
- `/api/studio/img-proxy` blocks private/loopback/metadata addresses and re-checks every redirect.
- Generated HTML has no scripts/external resources (validated). Still render it in a sandboxed iframe.
- Web photos belong to their owners: show `result.sources` (domain + link) near the image.
- Also fix in the Visual A-Z server: SafeSearch is OFF (`f=,,,`) and `scrapeDirectWebsite` has no SSRF guard — the studio already filters queries (blocked terms) but the search endpoint itself should be hardened.
